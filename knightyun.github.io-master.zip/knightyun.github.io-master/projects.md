---
layout: page
title: "GitHub Projects"
css: ["projects.css"]
js: [
    "https://cdnjs.cloudflare.com/ajax/libs/geopattern/1.2.3/js/geopattern.min.js",
    "projects.min.js"
]
---

{% include projects.html %}